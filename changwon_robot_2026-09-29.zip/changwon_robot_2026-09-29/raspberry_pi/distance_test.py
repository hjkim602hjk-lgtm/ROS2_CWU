import serial
import time
import math
import re

PORT = "/dev/ttyACM0"
BAUD = 115200

LEFT_TICKS_PER_REV = 3004.0
RIGHT_TICKS_PER_REV = 3015.0
WHEEL_DIAMETER_MM = 85.3

WHEEL_CIRCUMFERENCE_MM = math.pi * WHEEL_DIAMETER_MM

ser = serial.Serial(PORT, BAUD, timeout=0.1)
time.sleep(2)

left_tick = 0
right_tick = 0

try:
    ser.write(b'z')
    time.sleep(0.5)
    ser.reset_input_buffer()

    print("======================")
    print("FORWARD TEST START")
    print("======================")

    ser.write(b'f')
    start = time.time()

    while time.time() - start < 2.0:
        line = ser.readline().decode(errors="ignore").strip()

        # Handles clean lines and occasional concatenated serial text.
        matches = re.findall(r'ENC,(-?\d+),(-?\d+)', line)

        for l, r in matches:
            left_tick = int(l)
            right_tick = int(r)
            print(f"ENC,{left_tick},{right_tick}")

except KeyboardInterrupt:
    print("\nCTRL+C detected")

except Exception as e:
    print("\nERROR:", e)

finally:
    # Safety: always stop motors even after error / Ctrl+C.
    try:
        ser.write(b's')
        time.sleep(0.5)
    except Exception:
        pass

left_distance = abs(left_tick) / LEFT_TICKS_PER_REV * WHEEL_CIRCUMFERENCE_MM
right_distance = abs(right_tick) / RIGHT_TICKS_PER_REV * WHEEL_CIRCUMFERENCE_MM
average_distance = (left_distance + right_distance) / 2.0

print()
print("======================")
print("RESULT")
print("======================")
print(f"Left tick  : {left_tick}")
print(f"Right tick : {right_tick}")
print()
print(f"Left distance    : {left_distance:.1f} mm")
print(f"Right distance   : {right_distance:.1f} mm")
print(f"Average distance : {average_distance:.1f} mm")
print("======================")

ser.close()
