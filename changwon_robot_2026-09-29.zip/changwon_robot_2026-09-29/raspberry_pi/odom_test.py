import serial
import time
import math
import re
import sys
import select
import termios
import tty

PORT = "/dev/ttyACM0"
BAUD = 115200

WHEEL_DIAMETER_MM = 85.3
WHEEL_BASE_MM = 206.86

LEFT_TICKS_PER_REV = 3004.0
RIGHT_TICKS_PER_REV = 3015.0

# After FLIP_L=true, forward test produced positive counts on both sides.
# If a future wiring change reverses an encoder, change its sign to -1.
LEFT_ENCODER_SIGN = 1
RIGHT_ENCODER_SIGN = 1

WHEEL_CIRCUMFERENCE_MM = math.pi * WHEEL_DIAMETER_MM

ser = serial.Serial(PORT, BAUD, timeout=0.02)
time.sleep(2)

x = 0.0       # mm
y = 0.0       # mm
theta = 0.0   # rad

last_left = None
last_right = None

def update_odometry(left_tick, right_tick):
    global x, y, theta, last_left, last_right

    left_tick *= LEFT_ENCODER_SIGN
    right_tick *= RIGHT_ENCODER_SIGN

    if last_left is None:
        last_left = left_tick
        last_right = right_tick
        return

    dlt = left_tick - last_left
    drt = right_tick - last_right

    last_left = left_tick
    last_right = right_tick

    dL = dlt / LEFT_TICKS_PER_REV * WHEEL_CIRCUMFERENCE_MM
    dR = drt / RIGHT_TICKS_PER_REV * WHEEL_CIRCUMFERENCE_MM

    dC = (dL + dR) / 2.0
    dTheta = (dR - dL) / WHEEL_BASE_MM

    x += dC * math.cos(theta + dTheta / 2.0)
    y += dC * math.sin(theta + dTheta / 2.0)
    theta += dTheta
    theta = math.atan2(math.sin(theta), math.cos(theta))

    print(
        f"\rL:{left_tick:7d}  R:{right_tick:7d} | "
        f"X:{x:7.1f} mm  Y:{y:7.1f} mm  "
        f"TH:{math.degrees(theta):7.2f} deg",
        end="",
        flush=True
    )

old_settings = termios.tcgetattr(sys.stdin)
tty.setcbreak(sys.stdin.fileno())

print()
print("==========================================")
print("      CHANGWON ROBOT ODOMETRY TEST")
print("==========================================")
print(" W : Forward")
print(" X : Backward")
print(" A : Left")
print(" D : Right")
print(" S : Stop")
print(" Z : Reset encoder + odometry")
print(" Q : Quit")
print("==========================================")
print()

try:
    ser.write(b'z')
    time.sleep(0.3)
    ser.reset_input_buffer()

    while True:
        if select.select([sys.stdin], [], [], 0)[0]:
            key = sys.stdin.read(1).lower()

            if key == 'w':
                ser.write(b'f')
            elif key == 'x':
                ser.write(b'b')
            elif key == 'a':
                ser.write(b'l')
            elif key == 'd':
                ser.write(b'r')
            elif key == 's':
                ser.write(b's')
            elif key == 'z':
                ser.write(b'z')
                x = y = theta = 0.0
                last_left = None
                last_right = None
                print("\nODOMETRY RESET")
            elif key == 'q':
                break

        if ser.in_waiting:
            data = ser.read(ser.in_waiting).decode(errors="ignore")
            matches = re.findall(r'ENC,(-?\d+),(-?\d+)', data)

            for l, r in matches:
                update_odometry(int(l), int(r))

        time.sleep(0.005)

except KeyboardInterrupt:
    print("\nCTRL+C")

finally:
    try:
        ser.write(b's')
        time.sleep(0.3)
    finally:
        ser.close()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        print("\nMOTOR STOP")
        print("PROGRAM END")
