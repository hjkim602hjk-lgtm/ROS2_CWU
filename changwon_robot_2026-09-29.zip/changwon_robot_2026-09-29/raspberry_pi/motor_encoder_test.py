import serial
import time

PORT = "/dev/ttyACM0"
BAUD = 115200

ser = serial.Serial(PORT, BAUD, timeout=0.1)
time.sleep(2)

try:
    ser.write(b'z')
    time.sleep(0.5)

    print("=== FORWARD START ===")
    ser.write(b'f')

    start = time.time()

    while time.time() - start < 2:
        line = ser.readline().decode(errors="ignore").strip()
        if line:
            print(line)

finally:
    ser.write(b's')
    time.sleep(0.3)
    ser.close()
    print("=== STOP ===")
