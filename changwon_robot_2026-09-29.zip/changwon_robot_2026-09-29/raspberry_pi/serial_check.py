import serial
import time

PORT = "/dev/ttyACM0"
BAUD = 115200

ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)

print("=== STM RAW DATA ===")

for _ in range(30):
    line = ser.readline().decode(errors="ignore").strip()
    print("RX >", repr(line))

ser.close()
