# Changwon Robot — Motor / Encoder Bring-up

오늘(2026-09-29) 진행한 **STM32 + Raspberry Pi + MDD10A + 좌우 엔코더** 테스트 정리입니다.

## 1. 오늘 확인한 것

- Raspberry Pi ↔ STM32 USB Serial 통신 성공 (`115200 baud`)
- STM32 → MDD10A 모터 제어 성공
- 전진 / 후진 / 좌회전 / 우회전 / 정지 명령 성공
- 좌/우 엔코더 카운트 수신 성공
- 오른쪽 엔코더 `PB7` 입력에서 펄스가 잡히지 않는 현상 확인
- 오른쪽 엔코더 B를 `D3`로 옮긴 뒤 A/B 펄스가 거의 동일하게 들어오는 것 확인
- 바퀴 1회전당 tick 실측 완료
- tick → mm 거리 계산 성공
- 오도메트리 `x, y, theta` 테스트 코드 준비

## 2. 최종 배선

### Motor driver (MDD10A)

| 기능 | STM32 Nucleo-F446RE |
|---|---|
| Left DIR | D8 |
| Left PWM | D9 |
| Right DIR | D7 |
| Right PWM | D6 |

### Encoder

| 기능 | STM32 Nucleo-F446RE |
|---|---|
| Left Encoder A | D5 |
| Left Encoder B | D4 |
| Right Encoder A | D10 |
| Right Encoder B | **D3** |

> 오른쪽 Encoder B는 처음 `PB7 (CN7-21)`을 사용했지만 raw test에서 `B=0`이 계속 나왔습니다.  
> D3로 변경한 뒤 `A=2494 / B=2489` 수준으로 정상 동작했습니다.

## 3. STM32 Serial 명령

| 문자 | 동작 |
|---|---|
| `f` | forward |
| `b` | backward |
| `l` | left pivot |
| `r` | right pivot |
| `s` | stop |
| `z` | encoder zero |
| `1` | left motor only |
| `2` | right motor only |

STM32가 100 ms마다 다음 형식으로 보냅니다.

```text
ENC,<left_count>,<right_count>
```

예:

```text
ENC,1499,1406
ENC,2023,1893
ENC,2676,2502
```

## 4. 현재 측정 파라미터

| 파라미터 | 값 |
|---|---:|
| Wheel diameter | 85.30 mm |
| Wheel circumference | 267.98 mm |
| Left ticks / wheel rev | 3004 |
| Right ticks / wheel rev | 3015 |
| Left distance / tick | 0.08921 mm |
| Right distance / tick | 0.08888 mm |
| Wheel center-to-center distance (wheelbase) | 206.86 mm |
| Test PWM | 100 / 255 |
| Serial baud | 115200 |

1회전 tick은 직접 바퀴를 1회전시켜 측정했습니다.

- Left: `3004 tick/rev`
- Right: `3015 tick/rev`

2초 전진 거리 테스트에서 확인한 한 예:

```text
Left tick        : 2676
Right tick       : 2502
Left distance    : 238.7 mm
Right distance   : 222.4 mm
Average distance : 230.5 mm
```

좌우 모터 속도 차이는 약간 존재하므로 이후에는 encoder feedback 기반 속도 보정(PID 등)이 필요합니다.

## 5. 파일 구성

```text
changwon_robot_2026-09-29/
├── README.md
├── stm32/
│   └── changwon_robot_stm.ino
└── raspberry_pi/
    ├── serial_check.py
    ├── right_raw_test.py
    ├── motor_encoder_test.py
    ├── distance_test.py
    └── odom_test.py
```

### `stm32/changwon_robot_stm.ino`
최종 STM32 통합 코드. 모터 명령 처리 + 좌우 엔코더 count 출력.

### `raspberry_pi/serial_check.py`
STM32가 `ENC,...` 데이터를 실제로 보내는지 raw serial 확인.

### `raspberry_pi/right_raw_test.py`
오른쪽 엔코더 핀 진단 때 사용한 테스트 파일.

### `raspberry_pi/motor_encoder_test.py`
2초 전진 후 자동 정지하면서 encoder 값을 확인하는 가장 단순한 통합 테스트.

### `raspberry_pi/distance_test.py`
2초 전진 → encoder tick → 실제 이동거리(mm) 계산.  
`Ctrl+C` 또는 오류가 나도 `finally`에서 `s` 명령을 보내도록 구성.

### `raspberry_pi/odom_test.py`
키보드 `W/X/A/D/S/Z/Q`로 움직이면서 encoder 기반 `x, y, theta`를 실시간 계산.

## 6. Raspberry Pi 실행 준비

STM32 연결 확인:

```bash
ls /dev/ttyACM*
```

보통:

```text
/dev/ttyACM0
```

pyserial이 없다면:

```bash
sudo apt update
sudo apt install python3-serial -y
```

예시 실행:

```bash
python3 raspberry_pi/distance_test.py
```

또는:

```bash
python3 raspberry_pi/odom_test.py
```

## 7. 안전 / 작업 팁

- 처음 테스트할 때는 바퀴를 바닥에서 띄우고 실행합니다.
- 배선 변경 시 Raspberry Pi 전체를 매번 끌 필요는 없습니다.
- 모터/STM 전원을 안전하게 차단한 뒤 엔코더 선을 변경하고, Pi는 켜둔 채 SSH를 유지할 수 있습니다.
- 테스트 코드들은 가능한 경우 종료 시 `s` 명령을 보내 모터를 정지하도록 작성했습니다.
- STM 코드 수정/업로드는 노트북에서 하고, Raspberry Pi는 USB Serial 명령/ROS2 상위제어에 사용합니다.

## 8. 다음 단계

1. `odom_test.py`로 직진 시 `x` 증가와 `theta` 변화 확인
2. 제자리 회전으로 90도 회전 오차 확인
3. 좌우 wheel speed PID 적용
4. ROS2 `/odom` publish
5. 이후 LiDAR/PSD 회피 로직과 통합
